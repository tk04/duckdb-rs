#include "extension/core_functions/aggregate/holistic/approx_top_k.cpp"

#include "extension/core_functions/aggregate/holistic/quantile.cpp"

#include "extension/core_functions/aggregate/holistic/reservoir_quantile.cpp"

#include "extension/core_functions/aggregate/holistic/mad.cpp"

#include "extension/core_functions/aggregate/holistic/approximate_quantile.cpp"

#include "extension/core_functions/aggregate/holistic/mode.cpp"

